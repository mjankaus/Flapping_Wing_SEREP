function [BY_R,UY_R,BX_R] = SEREP_Function(S1xx,S2xx,S3xx,S1yy,S2yy,S3yy,U_NODE,B_NODE,U_Y,B_Y,B_X,N)
%SEREP_Function will use the SEREP reconstruction for the conditions
%identified in SEREP_Input.  Note that this script assumes the first and
%third modes are the primary modes used for reconstruction 

%%

%USING TWO MEASUREMENT POINTS, TWO MODES
if N==1
%Reconstruct BY from UY, BX
Phi_BY=[S1yy(U_NODE) S3yy(U_NODE); ...
        S1xx(B_NODE) S3xx(B_NODE)];
    
%Reconstruct UY from BY, BX
Phi_UY=[S1yy(B_NODE) S3yy(B_NODE); ...
        S1xx(B_NODE) S3xx(B_NODE)];
    
%Reconstruct BX from UY, BY
Phi_BX=[S1yy(U_NODE) S3yy(U_NODE); ...
        S1yy(B_NODE) S3yy(B_NODE)];

    

 UY_R=[];BY_R=[];BX_R=[];
 
    for i=1:length(U_Y);
    
  BY_R(:,i)= [S1yy S3yy]*(inv(Phi_BY)*[U_Y(i);B_X(i)]);
  UY_R(:,i)= [S1yy S3yy]*(inv(Phi_UY)*[B_Y(i);B_X(i)]);
  BX_R(:,i)= [S1xx S3xx]*(inv(Phi_BX)*[U_Y(i);B_Y(i)]);

    end
end
%% %USING THREE MEASUREMENT POINTS, THREE MODES (reconstructing physically measured data)

   if N==2
        
 Phi=[S1yy(U_NODE) S2yy(U_NODE) S3yy(U_NODE); ...
      S1yy(B_NODE) S2yy(B_NODE) S3yy(B_NODE);
      S1xx(B_NODE) S2xx(B_NODE) S3xx(B_NODE)];
    
 UY_R=[];BY_R=[];BX_R=[];
 
    for i=1:length(U_Y);
 
    BY_R(:,i)= [S1yy S2yy S3yy]*(inv(Phi)*[U_Y(i);B_Y(i);B_X(i)]);
    UY_R(:,i)= [S1yy S2yy S3yy]*(inv(Phi)*[U_Y(i);B_Y(i);B_X(i)]);
    BX_R(:,i)= [S1xx S2xx S3xx]*(inv(Phi)*[U_Y(i);B_Y(i);B_X(i)]);


    end
   end


  %% TWO MEASUREMENT POINTS, 1 MODE      
     if N==3
  
         %Reconstruction BY
      Phi_BY=[S1yy(U_NODE); ...
             S1xx(B_NODE)];
        
       T_BY=(Phi_BY'* Phi_BY)^-1* Phi_BY';

       %Reconstruction BX
      Phi_BX=[S1yy(U_NODE); ...
             S1yy(B_NODE)];
         
      T_BX=(Phi_BX'* Phi_BX)^-1* Phi_BX';
       
      %Reconstruction UY
        Phi_UY=[S1yy(B_NODE); ...
             S1xx(B_NODE)];
         
      T_UY=(Phi_UY'* Phi_UY)^-1* Phi_UY';

 UY_R=[];BY_R=[];BX_R=[];

for i=1:length(U_Y)
      BY_R(:,i)=[S1yy]*T_BY*[U_Y(i);B_X(i)];
      UY_R(:,i)=[S1yy]*T_BY*[B_Y(i);B_X(i)];
      BX_R(:,i)=[S1xx]*T_BX*[U_Y(i);B_Y(i)];
  end
        
     end
        
      %% USING TWO MEASUREMENT POINTS, 3 MODES; LEAST SQUARES METHOD
     if N==4
         
     
   
 Phi_BY=[S1yy(U_NODE) S2yy(U_NODE) S3yy(U_NODE); ...
      S1xx(B_NODE) S2xx(B_NODE)  S3xx(B_NODE)];       
     
     
   UY_R=[];BY_R=[];BX_R=[];

  for i=1:length(U_Y)
      Mes1=[U_Y(i);B_X(i)];
      Mes2=[B_Y(i);B_X(i)];
      Mes3=[U_Y(i);B_Y(i)];

      
      Coeff1= lsqminnorm(Phi_BY,Mes1);
      Coeff2= lsqminnorm(Phi_BY,Mes2);
      Coeff3= lsqminnorm(Phi_BY,Mes3);

      
      BY_R(:,i)=[S1yy S2yy S3yy]*Coeff1;
      UY_R(:,i)=[S1yy S2yy S3yy]*Coeff2;
      BX_R(:,i)=[S1yy S2yy S3yy]*Coeff3;
  end
     
     end
    
             
    
    


end

