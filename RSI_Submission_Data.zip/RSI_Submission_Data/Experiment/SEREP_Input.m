%William Johns, Lisa Davis & Mark Jankauski, Montana State University,2020
close all;clear all; clc;
addpath(genpath('DataSets'));

%% DESCRIPTION

% This script shows the reconstructions for the simple physical
% experiments.  The user can toggle through four different reconstruction
% types to see how the accuracy varies for different scenarios 
%% NODE SELECTIONS

%Identify which nodes are desired for reconstruction; nodes are shown in
%the ABAQUS .cae file

U_NODE=145;
B_NODE=204;

%% RECONSTRUCTION SELECTION

%Choose desired reconstruction type
% N=1,  TWO MEASUREMENT POINTS, TWO MODES
% N=2,  THREE MEASUREMENT POINTS, THREE MODES
% N=3,  TWO MEASUREMENT POINTS, ONE MODE  
% N=4   TWO MEASUREMENT POINTS, 3 MODES; LEAST SQUARES OPTIMIZATION METHOD

N=1;

%% 
%Importing the mode shape data as before, and unique/sorting indeces
% The following modal strain reports are generated from the Experimental_Triangular_Wing.cae


%Uniaxial Strain Gage
Mode1_R1=importdata('Exp_Assembly_M1_Mod.rpt');
Mode2_R1=importdata('Exp_Assembly_M2_Mod.rpt');
Mode3_R1=importdata('Exp_Assembly_M3_Mod.rpt');

%Construct Master node list (shared nodes will be counted as belonging to
%the sensor
nodelist=[Mode1_R1.data(:,1)];

%Construct Master node list (shared nodes will be counted as belonging to
%the sensor
nodelist=[Mode1_R1.data(:,1)];

%Extract Mode 1 Y strains at top of wing and bottom of sensor
S1yy=[Mode1_R1.data(:,6)];

%Extract Mode 1 X strains at the top of the wind and the bottom of the sensor
S1xx=[Mode1_R1.data(:,4)];

%Extract Mode 2 Y strains at top of wing and bottom of sensor
S2yy=[Mode2_R1.data(:,6)];

%Extract Mode 2 X strains at the top of the wind and the bottom of the sensor
S2xx=[Mode2_R1.data(:,4)];

%Extract Mode 2 Y strains at top of wing and bottom of sensor
S3yy=[Mode3_R1.data(:,6)];

%Extract Mode 2 X strains at the top of the wind and the bottom of the sensor
S3xx=[Mode3_R1.data(:,4)];


%% IMPORT DATA

%Import experimental measurements
Dat=csvread('SEREP_Angle_45_Freq_6Hz.lvm',23,0);
%Data starts at 5 seconds, ends at 15 seconds; Fs=1000 Hz
START=1;     %Starting sample index
END=10000;      %Ending sample index

%Index time vector
t=Dat(START:END,1);

%Index position data (Volts -- 5 volts/360 degrees; centered ~2.5 volts)
Pos_Volt=Dat(START:END,2);

%Index strain data (dimensionless units)
U_Y=Dat(START:END,3);       %uni-axial gage, y-strain 
B_Y=Dat(START:END,4);       %bi-axial gage, y-strain (measures along wing length)
B_X=Dat(START:END,5);       %bi-axial gage, x-strain (measures along wing width)

% Remove any prestrain from the data
U_Y=U_Y-mean(U_Y);
B_Y=B_Y-mean(B_Y);
B_X=B_X-mean(B_X);


%% RECONSTRUCT AND PLOT

[BY_R,UY_R,BX_R] = SEREP_Function(S1xx,S2xx,S3xx,S1yy,S2yy,S3yy,U_NODE,B_NODE,U_Y,B_Y,B_X,N);

figure()
plot(t,BY_R(B_NODE,:),t,B_Y,'--')
title('Strain v. Time, B_Y Reconstruction')
legend('Reconstructed','Measured')
xlabel('Time (sec)')
ylabel('Strain')

figure()
plot(t,UY_R(U_NODE,:),t,U_Y,'--')
title('Strain v. Time, U_Y Reconstruction')
legend('Reconstructed','Measured')
xlabel('Time (sec)')
ylabel('Strain')


figure()
plot(t,BX_R(B_NODE,:),t,B_X,'--')
title('Strain v. Time, B_X Reconstruction')
legend('Reconstructed','Measured')
xlabel('Time (sec)')
ylabel('Strain')
