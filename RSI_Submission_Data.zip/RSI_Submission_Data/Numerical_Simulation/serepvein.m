function [ir,Rdispv]=serepvein(M1_U3,M2_U3,M3_U3,M4_U3,WingStrainv,WingDef,w_k,t)


%Import the Strain modes on the veins so we can put sensors on them.
%Next, we will import the two modes shapes and index modal displacements
vein_Mode1=importdata('sim_m1_vein.rpt');
vein_Mode2=importdata('sim_m2_vein.rpt');
vein_Mode3=importdata('sim_m3_vein.rpt');
vein_Mode4=importdata('sim_m4_vein.rpt');

% Get the first index of each node in the data as there are duplicates
nodelist=vein_Mode1.data(:,1);
[nodelist,ia,~]=unique(nodelist);
bb=length(nodelist);
%[nodelist,sortidx]=sort(nodelist);

% Import modes shapes and remove repeated nodes
vein_M1_E11=vein_Mode1.data(ia,3);
vein_M2_E11=vein_Mode2.data(ia,3); 
vein_M3_E11=vein_Mode3.data(ia,3); 
vein_M4_E11=vein_Mode4.data(ia,3); 

%Calculate Minimal Normalized Nodal Displacement for strain in y
% and average NND at each Node
NMDmin=zeros(bb,1);
NMDavg=zeros(bb,1);
NMDwgh=zeros(bb,1);

for ii=1:bb
    NMD1=vein_M1_E11(ii)^2/w_k(1);
    NMD2=vein_M2_E11(ii)^2/w_k(2);
    NMD3=vein_M3_E11(ii)^2/w_k(3);
    NMD4=vein_M4_E11(ii)^2/w_k(4);
    NMDmin(ii)=min([NMD1 NMD2 NMD3 NMD4]);
    NMDavg(ii)=mean([NMD1 NMD2 NMD3 NMD4]);
end
NMDwgh=NMDmin.*NMDavg;

num_sensors=[4:4:16];
% num_sensors=4;

%Set the number of sensors
for jj=1:length(num_sensors)
    aa=num_sensors(jj);
    [~,irnode]=maxk(NMDwgh,aa);
    ir=nodelist(irnode);
    
  
%Construct the SEREP transformation matrices
Phi=[M1_U3 M2_U3 M3_U3 M4_U3];
PhiR=Phi(ir,:);
T=(PhiR.'*PhiR)^-1*PhiR.';


% Construct the transfomrmation matrix in the direction of the veins
Phiv=[vein_M1_E11 vein_M2_E11 vein_M3_E11 vein_M4_E11];
PhiRv=Phiv(irnode,:);
Tv=(PhiRv.'*PhiRv)^-1*PhiRv.';

%Reconstruct the displacement
Rdispv=[];
alphav=[]; 
for i =1:length(t)
%Find modal contributions

alphav=[alphav Tv*(WingStrainv(ir,i)+(10*(rand(length(ir),1)-0.5)/1e6))]; %Adds measurement noise of +/- 5 microstrain%

%Reconstructed Displacement
Rdispv = [Rdispv Phi*alphav(:,i)]; %Reconstruct Deformation from alphav

end




20*log10(trapz(t,abs(WingDef(10,:)-Rdispv(10,:))));
20*log10(trapz(t,abs(WingDef(25,:)-Rdispv(25,:))));



end
end

