function [ir,Rdispv]=serepvein_spaced_displacement(Xcor,Ycor,Zcor,M1_U3,M2_U3,M3_U3,M4_U3,WingStrainv,WingDef,w_k,t)
%%Node 16 is wing tip, node 24 is the trainling edge
%nodes to retain
min_spacing=.0;

%Import the Strain modes on the veins so we can put sensors on them.
%Next, we will import the two modes shapes and index modal displacements
vein_Mode1=importdata('sim_m1_vein.rpt');
vein_Mode2=importdata('sim_m2_vein.rpt');
vein_Mode3=importdata('sim_m3_vein.rpt');
vein_Mode4=importdata('sim_m4_vein.rpt');

% Get the first index of each node in the data as there are duplicates
nodelist=vein_Mode1.data(:,1);
[nodelist,ia,~]=unique(nodelist);
Xcor_vein=Xcor(nodelist);
Ycor_vein=Ycor(nodelist);
Zcor_vein=Zcor(nodelist);
%[nodelist,sortidx]=sort(nodelist);

% Import modes shapes and remove repeated nodes
vein_M1_E11=vein_Mode1.data(ia,2);
vein_M2_E11=vein_Mode2.data(ia,2); 
vein_M3_E11=vein_Mode3.data(ia,2); 
vein_M4_E11=vein_Mode4.data(ia,2); 

num_sensors=[4:4:16];
% num_sensors=16;


%Set the number of sensors
for jj=1:length(num_sensors)
    aa=num_sensors(jj);
    
    ir=[];               %sensor node number
    irnode=[];           %sensor index in nodelist
    locations=1:length(nodelist);  %possible sensor locations
    
    %Calculate Weighted Normalized Nodal Displacement for strain along the vein
    bb=length(locations);
    NMDmin=zeros(bb,1);
    NMDavg=zeros(bb,1);
    NMDwgh=zeros(bb,1);
    for ii=1:bb
        NMD1=vein_M1_E11(ii)^2/w_k(1);
        NMD2=vein_M2_E11(ii)^2/w_k(2);
        NMD3=vein_M3_E11(ii)^2/w_k(3);
        NMD4=vein_M4_E11(ii)^2/w_k(4);
        NMDmin(ii)=min([NMD1 NMD2 NMD3 NMD4]);
        NMDavg(ii)=mean([NMD1 NMD2 NMD3 NMD4]); 
    end
    NMDwgh=NMDmin.*NMDavg;
    
    for kk=1:aa
    %Select the next sensor
    [~,irnodeidx]=max(NMDwgh(locations));
    irnode=[irnode locations(irnodeidx)];
    ir=[ir nodelist(locations(irnodeidx))];
    locations(irnodeidx)=[];
    %Remove sensors within min_space from consideration
    d=sqrt((Xcor_vein(locations)-Xcor_vein(irnodeidx)).^2+(Ycor_vein(locations)-Ycor_vein(irnodeidx)).^2);
    locations(find(d<=min_spacing))=[];
    end
    
    
%Construct the SEREP transformation matrices
Phi=[M1_U3 M2_U3 M3_U3 M4_U3];
PhiR=Phi(ir,:);
T=(PhiR.'*PhiR)^-1*PhiR.';

% Construct the transfomrmation matrix in the direction of the veins
Phiv=[vein_M1_E11 vein_M2_E11 vein_M3_E11 vein_M4_E11];
PhiRv=Phiv(irnode,:);
Tv=(PhiRv.'*PhiRv)^-1*PhiRv.';

%Reconstruct the displacement
Rdispv=[];
alphav=[]; 
for i =1:length(t)
%Find modal contributions
alphav=[alphav Tv*(WingDef(ir,i)+(1*(rand(length(ir),1)-0.5)/1000))]; %Adds random noise of +/- 0.5 mm to reconstruction 
%Reconstructed Displacement
Rdispv = [Rdispv Phi*alphav(:,i)]; %Reconstruct Deformation from alphav
end


20*log10(trapz(t,abs(WingDef(10,:)-Rdispv(10,:))));
20*log10(trapz(t,abs(WingDef(25,:)-Rdispv(25,:))));



end
end

