function dy = Modal_Response_Solve(t1,y,t,Stiffness,Excitation,Damp)
%MODAL_RESPONSE Summary of this function goes here
%   Detailed explanation goes here

%Initialize the state variables
dy=zeros(2,1); 
dy(1)=y(2);

%Interpolate stiffness, excitation into ODE solver time scale 
SS=interp1(t,Stiffness,t1);
EE=interp1(t,Excitation,t1);

%Define second state equation 
dy(2)=EE-SS*y(1)-Damp*y(2);
end

