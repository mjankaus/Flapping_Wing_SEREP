%William Johns, Lisa Davis & Mark Jankauski, Montana State, 2020
close all;clear all;clc;
addpath(genpath('Wing_Data'));

%% DESCRIPTION

%The purpose of this script is to solve for the wing's dynamic response

%% VALIDATION NODES

%Nodes referenced for reconstruction validation.  Nodes are shown in the
%SEREP_SimulationWing.cae ABAQUS file.
LE_Node=10;
TE_Node=25;
%% KINEMATIC INPUTS

% Here we will define all the constants that populate the kinematics.
% We assume all wing rotations are harmonic and of the form N=N0*sin(w*t+phi_n), where N is the
% prescribed angular displacement, N0 is rotation amplitude (in radians), w
% is the flapping frequency (rad/sec) and phi_n is the phase delay (in
% rad).  

A   =   60;   %Roll amplitude, degrees
Aph =   0;    %Roll phase, degrees
B   =   45;   %Pitch amplitude, degrees
Bph =   -90;   %Pitch phase, degrees 
G   =   0;    %Yaw amplitude, degrees
Gph =   0;    %Yaw phase, degrees

f_flap= 25;   %Flap frequency, Hz 

%Unit conversions; change degrees to radians, flap freq from Hz to rad/sec
A=deg2rad(A); Aph=deg2rad(Aph);
B=deg2rad(B); Bph=deg2rad(Bph);
G=deg2rad(B); Gph=deg2rad(Bph);
w= f_flap*2*pi; 

%Timing vector
%Creating a time vector
Per = 10;                                %Number of periods (wing flaps) to run the simulation
TF  = Per/(w/(2*pi));                   %Final simulation time
h   = 1000;                             %# of time steps per wingbeat; defines time resolution
t   = linspace(0,Per/(w/(2*pi)),h*Per); %Determined time vector


%% DYNAMIC INPUTS

%In this section, we will input the dynamic parameters, including natural
%frequencies determined via FEA, Ak,Bk, and the damping ratio

w_k=[60 84 107 142];      %Wing natural frequencies, determined via ABAQUS, in Hz
w_k=w_k*2*pi;             %Convert to rad/sec
load('A1.mat');load('A2.mat');load('A3.mat');load('A4.mat');load('B1.mat');load('B2.mat');load('B3.mat'),load('B4.mat');
A_k=[A1 A2 A3 A4]; %Previously determined Ak vector
B_k=[B1 B2 B3 B4]; %Previously determined Bk vector
  

zeta=[0.05 0.05 0.05 0.05];             %Damping ratios
Damp=2*w_k.*zeta;                       %Damping coefficient 
%% KINEMATIC CALCULATIONS

% Here, we calculate the time derivatives of the prescribed pitch-roll-yaw
% angular rotations.  We compile those into the angular velocity and
% angular acceleration vectors 

Alpha=A*sin(w*t+Aph);
Alpha_D=A*w*cos(w*t+Aph);
Alpha_DD=-A*w^2*sin(w*t+Aph);

Beta=B*sin(w*t+Bph);
Beta_D=B*w*cos(w*t+Bph);
Beta_DD=-B*w^2*sin(w*t+Bph);

Gamma=G*sin(w*t+Gph);
Gamma_D=G*w*cos(w*t+Gph);
Gamma_DD=-G*w^2*sin(w*t+Gph);

%Now, the angular velocity vector and angular accelerations vectors
%are:

Omega=[Alpha_D.*cos(Beta).*cos(Gamma)+Beta_D.*sin(Gamma); Beta_D.*cos(Gamma)-Alpha_D.*sin(Gamma).*cos(Beta);Gamma_D+Alpha_D.*sin(Beta)];

Omega_D=[Alpha_DD.*cos(Beta).*cos(Gamma)-Alpha_D.*Beta_D.*sin(Beta).*cos(Gamma)-Alpha_D.*Gamma_D.*cos(Beta).*sin(Gamma)+Beta_DD.*sin(Gamma)+Beta_D.*Gamma_D.*cos(Gamma);...
        Beta_DD.*cos(Gamma)-Beta_D.*Gamma_D.*sin(Gamma)-Alpha_DD.*sin(Gamma).*cos(Beta)-Alpha_D.*Gamma_D.*cos(Beta).*cos(Gamma)+Alpha_D.*Beta_D.*sin(Gamma).*sin(Beta);...
        Gamma_DD+Alpha_DD.*sin(Beta)+Alpha_D.*Beta_D.*cos(Beta)];

%% TIME-VARYING STIFFNESS AND EXCITATION TERMS

%Time varying stiffness
for i=1:length(w_k)
Stiffness(i,:)=w_k(i)^2*ones(size(t))-(Omega(1,:).^2+Omega(2,:).^2);
end

%Time varying inertial excitation
for i=1:length(w_k)
    for j=1:length(t)
    Excitation(i,j)=dot(B_k(:,i),Omega_D(:,j))-Omega(3,j)*dot(A_k(:,i),Omega(:,j));
    end
end

%% SOLVE THE ODE 

% With the excitation and stiffness known, we have all the parameters
% necessary to solve for the modal response qk.  We will utilize
% ODE 45.  

% We will preallocate modal position Q and modal velocity QD
Q   = zeros(length(w_k),length(t));
QD  = zeros(length(w_k),length(t));

%The the following lines of code: t1 is the ODE time stepping, y are the
%state variables (modal position and velocity), t is the externally defined
%time used for kinematics, stiffness/excitation are the previously defined
%terms, Damp is the damping parameter, and [0;0] denotes the initial
%conditions.  We assume the system starts from rest.

for i=1:length(w_k)
[T1 q1]=ode45(@(t1,y) Modal_Response_Solver(t1,y,t,Stiffness(i,:),Excitation(i,:),Damp(i)),t,[0,0]);

Q(i,:)  =q1(:,1)';
QD(i,:) =q1(:,2)';

end



%% INDEXING MODE SHAPES DATA FOR RECONSTRUCTION



%Importing the mode shape data, and unique/sorting indeces
load('ia.mat'); load('sortidx.mat');
Mode1=importdata('sim_m1_mod.rpt');
Mode2=importdata('sim_m2_mod.rpt');
Mode3=importdata('sim_m3_mod.rpt');
Mode4=importdata('sim_m4_mod.rpt');

M1_U3=Mode1.data(ia,2); M1_U3=M1_U3(sortidx);
M2_U3=Mode2.data(ia,2); M2_U3=M2_U3(sortidx);
M3_U3=Mode3.data(ia,2); M3_U3=M3_U3(sortidx);
M4_U3=Mode4.data(ia,2); M4_U3=M4_U3(sortidx);


WingDef=M1_U3*Q(1,:)+M2_U3*Q(2,:)+M3_U3*Q(3,:)+M4_U3*Q(4,:); %Rreconstruct full field wing deformation

%We can also estimate the modal strain along the veins
M1_E11=Mode1.data(ia,3); M1_E11=M1_E11(sortidx);
M2_E11=Mode2.data(ia,3); M2_E11=M2_E11(sortidx);
M3_E11=Mode3.data(ia,3); M3_E11=M3_E11(sortidx);
M4_E11=Mode4.data(ia,3); M4_E11=M4_E11(sortidx);

WingStrainv=M1_E11*Q(1,:)+M2_E11*Q(2,:)+M3_E11*Q(3,:)+M4_E11*Q(4,:);    %Reconstruct full field wing strain

%Geometric data
Geo = importdata('geometry.inp'); %Import geometric data
Xcor = Geo(:,2); % x coordinates of nodes 
Ycor = Geo(:,3); % y coordinates of nodes
Zcor = Geo(:,4); % z coordinates of nodes (all zeros)

%% RECONSTRUCTION
% Reconstruction options -- the first is strain to displacement, the second
% is displacement to displacement.  Uncomment the reconstruction of
% interest  

[ir,Rdispv]=serepvein(M1_U3,M2_U3,M3_U3,M4_U3,WingStrainv,WingDef,w_k,t);
% [ir,Rdispv]=serepvein_spaced_displacement(Xcor,Ycor,Zcor,M1_U3,M2_U3,M3_U3,M4_U3,WingStrainv,WingDef,w_k,t);


LEr=Rdispv(LE_Node,:);
LE=WingDef(LE_Node,:);
TEr=Rdispv(TE_Node,:);
TE=WingDef(TE_Node,:);

figure()
plot(t,LE,t,LEr,'r--')
xlabel('Time (sec)')
ylabel('Displacement (m)')
title('Displacement v. Time, Leading Edge')
legend('Exact','Reconstructed')

figure()
plot(t,TE,t,TEr,'r--')
xlabel('Time (sec)')
ylabel('Displacement (m)')
title('Displacement v. Time, Trailing Edge')
legend('Exact','Reconstructed')


